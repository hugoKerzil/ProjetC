#include <stdio.h>

int main(void) {
    int *ptr = NULL;
    *ptr = 17;
    return 0;
}